﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.Class_lot
{
    class Aria_lot_line
    {
        public string lot_id { get; set; }
        public string user_name { get; set; }
        public string line_state { get; set; }
        public string working_lot { get; set; }
        public string line_temp { get; set; }
        public string line_humidity { get; set; }

    }
}
