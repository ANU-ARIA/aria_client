﻿namespace WindowsFormsApp2
{
    public class Aria_user
    {
        public string user_id { get;set; }
        public string pass_word { get; set; }
        public int level { get; set; }
        public string e_mail { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
    }


}