﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using Newtonsoft.Json;
using MESComm;
using System.Windows.Forms;
using WindowsFormsApp2;
using WindowsFormsApp2.Class_lot;
using WindowsFormsApp2.Class_Model;

namespace MESComm
{
    class ServerComm
    {
        private   IPEndPoint    m_clientAddress;
        private   IPEndPoint    m_serverAddress;
        private   TcpClient     m_TcpClient;
        private   NetworkStream m_streamClient;

        string    m_sBindIp = "220.69.249.232";
        string    m_sServerIp = "220.69.249.232";
        const int m_nPort = 4000;
        bool      m_bSimulate = true;

        public IEnumerable<Control> Controls { get; private set; }

        public ServerComm(bool _bSimul)
        {
            m_bSimulate = _bSimul;
        }

        public ServerComm()
        {
        }

        public void InInitializer()
        {

        }

        public void Finalize()
        {

        }


        public int Connect(string sIpAddress, int nPort)
        {
            int nRet = 0;

            if (!m_bSimulate)
            {
                m_clientAddress = new IPEndPoint(IPAddress.Parse(m_sBindIp), m_nPort);
                m_serverAddress = new IPEndPoint(IPAddress.Parse(m_sServerIp), m_nPort);

                m_TcpClient     = new TcpClient(m_clientAddress);
                m_TcpClient.Connect(m_serverAddress);

                m_streamClient  = m_TcpClient.GetStream();
            }
            return nRet;
        }

        public void Close()
        {
            if (!m_bSimulate)
            {
                m_streamClient.Close();
                m_TcpClient.Close();
            }
        }

        public int req_user_log_in(string sId, string sPw)
        {
            string sMsg  = "";
            int nRet     = Send(sMsg);
            return nRet;
        }

        //Model Insert
        public int req_model_insert(Model _md)
        {
            // MES Server에 전달할 메세지를 만든다.
            string message;
            message = "{{#@@," + _md.model_id + "," + _md.temp_margin + "," + _md.humid_margin + "," + _md.model_name + ",#}}";

            int nErr = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "1,1,1,chokopi,";
            }

            int nAck=0;
            string sReason = "";

            analyze_req_model_insert(responseData, ref nAck, ref sReason);

            return nErr;
        }

        public void analyze_req_model_insert(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

    
        // 모델 responseData 리스트
        private int analyze_req_model_list(string _responseData, ref List<Aria_model> _list_model)
        {
            string[] arr = _responseData.Trim().Split(',');


            for (int i = 0; i < arr.Length / 4; i++)
            {
                Aria_model md = new Aria_model();

                md.model_id      = arr[i * 4];
                md.temp_margin   = Int32.Parse(arr[i * 4 + 1]);
                md.humid_margin  = Int32.Parse(arr[i * 4 + 2]);
                md.model_name    = arr[i * 4 + 3];
         
                _list_model.Add(md);
            }

            return 0;
        }

        //User Insert
        public string req_user_insert(Aria_user _us)
        {
            string message = "";
            message = "{{#!!," + _us.user_id + ",#}}"; ;

            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "kim,1234,1,chokopi@com,kim,seong,Sin,1234,1,chokopi@com,Sin,su,";
            }

            int nAck = 0;
            string sReason = "";

            analyze_req_user_insert(responseData, ref nAck, ref sReason);

            return responseData;
        }

        public void analyze_req_user_insert(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

        //User Delete
        public int req_user_delete(Aria_user _us)
        {


            string message = "";
            message = "{{#!!," + _us.user_id + ",#}}"; ;

            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "Sin,1234,1,chokopi@com,Sin,su,";
            }

            int nAck = 0;
            string sReason = "";

            analyze_req_user_delete(responseData, ref nAck, ref sReason);

            return nRet;
        }

        public void analyze_req_user_delete(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

        //User Update
        public int req_user_update(Aria_user _us)
        {


            string message = "";
            message = "{{#!#," + _us.user_id + "," + _us.pass_word + "," + _us.level + "," + _us.e_mail + "," + _us.first_name +
                    "," + _us.last_name + ",#}}";

            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "Lee,1234,1,chokopi@com,Lee,Ju,";
            }

            int nAck = 0;
            string sReason = "";

            analyze_req_user_update(responseData, ref nAck, ref sReason);

            return nRet;
        }

        public void analyze_req_user_update(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

        //User Search
        public int req_user_search(Aria_user _us)
        {
            string message = "";
            message = "{{#!%," + _us.user_id + ",#}}";

            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "Dong,1234,1,chokopi@com,Dong,Woo,";
            }

            int nAck = 0;
            string sReason = "";

            analyze_req_user_search(responseData, ref nAck, ref sReason);

            return nRet;
        }

        public void analyze_req_user_search(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

        //User All Search
        public int req_user_all_search(Aria_user _us)
        {
            string message = "";
            message = "{{#!%," + _us.user_id + ",#}}";

            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "Doo,1234,1,chokopi@com,Doo,sToo,";
            }

            int nAck = 0;
            string sReason = "";

            analyze_req_user_all_search(responseData, ref nAck, ref sReason);

            return nRet;
        }

        public void analyze_req_user_all_search(string responseData, ref int _nAck, ref string _sReason)
        {
            _nAck = 0;
            _sReason = "거절 사유";

        }

        // 유저 responseData 리스트
        public static List<Aria_user> analyze_req_user_list(string _responseData, ref List<Aria_user> _list_user)
        {
            string[] arr = _responseData.Trim().Split(',');


            for (int i = 0; i < arr.Length / 6; i++)
            {
                Aria_user us = new Aria_user();

                us.user_id = arr[i * 6];
                us.pass_word = arr[i * 6 + 1];
                us.level = Int32.Parse(arr[i * 6 + 2]);
                us.e_mail = arr[i * 6 + 3];
                us.first_name = arr[i * 6 + 4];
                us.last_name = arr[i * 6 + 5];

                _list_user.Add(us);
            }

            return _list_user;
        }


        // 작업지시 call-by reference
        public int req_lot_list(ref List<Aria_lot_line> _list_lot, string _message)
        {
            string message = _message;
            int nMsgId = 1;
            int nRet = Send(message);

            // 메세지 수신
            string responseData = "";
            byte[] data = new byte[1280];
            int bytes;
            if (!m_bSimulate)
            {
                bytes = m_streamClient.Read(data, 0, data.Length);
                responseData = Encoding.Default.GetString(data, 0, bytes);
            }
            else
            {
                responseData = "lot01,kim,작업중,초코빵,24,40,";
            }
            analyze_req_lot_list(responseData, ref _list_lot);

            return nRet;
        }


        // ------------------------------------------------------- 주현 수정 -------------------------------------------------------
        // 작업지시 responseData 리스트
        //private int analyze_req_lot_list(string _responseData, ref List<Aria_lot_line> _list_lot)
        //{
        //    string[] arr = _responseData.Trim().Split(',');


        //    for (int i = 0; i < arr.Length / 5; i++)
        //    {
        //        Aria_lot_line lot = new Aria_lot_line();

        //        lot.lot_id = arr[i * 5];
        //        lot.user_name = arr[i * 5 + 1];
        //        lot.line_state = arr[i * 5 + 2];
        //        lot.line_temp = arr[i * 5 + 3];
        //        lot.line_humidity = arr[i * 5 + 4];

        //        _list_lot.Add(lot);
        //    }

        //    return 0;
        //}
        /*
         *  public int plus(int a, int b)
         * {
         *     int c = a+b;
         *     return c;
         *} 
         */

        // 작업지시 responseData 리스트
        private List<Aria_lot_line> analyze_req_lot_list(string _responseData, ref List<Aria_lot_line> _list_lot)
        {
            string[] arr = _responseData.Trim().Split(',');


            for (int i = 0; i < arr.Length / 5; i++)
            {
                Aria_lot_line lot = new Aria_lot_line();

                lot.lot_id = arr[i * 5];
                lot.user_name = arr[i * 5 + 1];
                lot.line_state = arr[i * 5 + 2];
                lot.line_temp = arr[i * 5 + 3];
                lot.line_humidity = arr[i * 5 + 4];

                _list_lot.Add(lot);
            }

            return _list_lot;
        }




        private int Send(string _message)
        {
            int nRet = 0;

            byte[] data = System.Text.Encoding.Default.GetBytes(_message);

            if (!m_bSimulate)
            {
                m_streamClient.Write(data, 0, data.Length);
            }

            return nRet;
        }

    }
}
