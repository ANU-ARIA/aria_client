﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.Class_Model
{
    class Aria_model
    {
        public string model_id { get; set; }
        public float temp_margin { get; set; }
        public float humid_margin { get; set; }
        public string model_name { get; set; }
    }
}
