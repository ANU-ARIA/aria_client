﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Lot_list : Form
    {
        public Lot_list()
        {
            InitializeComponent();
        }

        private void search_Click(object sender, EventArgs e)
        {

        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Line_box_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
